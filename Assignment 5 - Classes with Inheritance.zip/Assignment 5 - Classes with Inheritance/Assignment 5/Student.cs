﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_5
{
    class Student : Person
    {
        // static int used to keep track of the number of students that are created
        public static int StudentCreationCounter = 0;

        // FirstName, LastName, and Age are inherited from the Person class
        public Student(string FirstName, string LastName, int Age) : base(FirstName, LastName, Age)
        {
            this.FirstName = FirstName;
            this.LastName = LastName;
            this.Age = Age;
            // adds one to the Student Creation Counter
            StudentCreationCounter++;
        }

        // added to just show understanding of how to add an exclusive method to class per assignment instructions
        public void TakeTest()
        {

        }

        // method to return the StudentCreationCounter which keeps track of the number of Student type objects created
        public int getCounter()
        {
            return StudentCreationCounter;
        }

    }
}
