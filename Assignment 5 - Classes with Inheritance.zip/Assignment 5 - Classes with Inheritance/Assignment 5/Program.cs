﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_5
{
    class Program
    {
        static void Main(string[] args)
        {
            // creating three objects of the student type
            Student student1 = new Student("Johnny", "Appleseed", 23423);
            Student student2 = new Student("Bruce", "Wayne", 23);
            Student student3 = new Student("Johny", "Wick", 43);

            // creating a new object of the course type
            Course course1 = new Course("Underwater Basketweaving");

            // using the SetStudentInformation within the Course class to set the student information within the StudentArray inside the course class
            course1.SetStudentInformation(student1);
            course1.SetStudentInformation(student2);
            course1.SetStudentInformation(student3);

            // creating a new object of the teacher type
            Teacher teacher1 = new Teacher("Bruce", "Banner", 2343);

            // SetTeacherInformation method used to insert teacher information into the TeacherArray in the Course class
            course1.SetTeacherInformation(teacher1);

            // creating a new object of the Degree type
            Degree myDegree = new Degree("Bachelors of Science", course1);

            // creating a new object of the UProgram type
            UProgram uniProgram1 = new UProgram("Information Technology", myDegree);

            Console.WriteLine("The {0} program contains the {1} degree", uniProgram1.UProgramName, myDegree.UDegreeName);
            Console.WriteLine();
            Console.WriteLine("The {0} degree conains the course {1}", myDegree.UDegreeName, course1.CourseName);
            Console.WriteLine();
            Console.WriteLine("The {0} course contains {1} students", course1.CourseName, student1.getCounter());
            Console.WriteLine();

        }
    }
}
