﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_5
{
    public class Teacher : Person
    {
        // LastName FirstName and Age are inherited from the Person class
        public Teacher(string LastName, string FirstName, int Age) : base(LastName, FirstName, Age)
        {
            this.FirstName = FirstName;
            this.LastName = LastName;
            this.Age = Age;
        }

        // Method added to demonstrate understanding of how to add exclusive methods to a class per assignment instructions
        public void GradeTest()
        {

        }

    }
}
