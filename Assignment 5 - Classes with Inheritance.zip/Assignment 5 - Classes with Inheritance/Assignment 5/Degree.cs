﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_5
{
    class Degree
    {
        private string uDegreeName;
        private Course courseName;

        public string UDegreeName { get => uDegreeName; set => uDegreeName = value; }
        public Course CourseName { get => courseName; set => courseName = value; }

        public Degree(string UDegreeName, Course CourseName)
        {
            this.courseName = CourseName;
            this.uDegreeName = UDegreeName;
        }
    }
}
