﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_5
{
    class UProgram
    {
        private string uProgramName;
        private Degree degree1;

        public string UProgramName { get => uProgramName; set => uProgramName = value; }
        internal Degree Degree1 { get => degree1; set => degree1 = value; }

        public UProgram(string UProgramName, Degree Degree1)
        {
            this.UProgramName = uProgramName;
            this.Degree1 = degree1;
        }

        // method simply used for returning the university program name
        public string GetName()
        {
            return UProgramName;
        }

    }
}
