﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_5
{
    class Course
    {
        private Student[] studentArray;
        private Teacher[] teacherArray;
        private string courseName;

        internal Student[] StudentArray { get => studentArray; set => studentArray = value; }
        internal Teacher[] TeacherArray { get => teacherArray; set => teacherArray = value; }
        public string CourseName { get => courseName; set => courseName = value; }

        public Course(string CourseName)
        {
            this.courseName = CourseName;
            this.StudentArray = new Student[3];
            this.TeacherArray = new Teacher[3];
        }

        // method used to insert student information into student array
        public void SetStudentInformation(Student mystudent)
        {
            int counter = 0;

            // while loop used to insure that student information is being placed into the next available empty array element
            while (StudentArray[counter] != null)
            {
                counter++;
            }

            // inserts student information into location of counter in array
            StudentArray[counter] = mystudent;
        }

        // method used to insert teacher information into teacher array
        public void SetTeacherInformation(Teacher myteacher)
        {
            int counter = 0;

            // while loop used to insure that teacher information is being placed into the next available empty array element
            while (TeacherArray[counter] != null)
            {
                counter++;
            }

            // inserts teacher information into location of counter within array
            TeacherArray[counter] = myteacher;
        }
    }
}
