﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_7
{
    class Course
    {
        private ArrayList studentArray;
        private ArrayList teacherArray;
        private string courseName;

        public ArrayList StudentArray { get => studentArray; set => studentArray = value; }
        public ArrayList TeacherArray { get => teacherArray; set => teacherArray = value; }
        public string CourseName { get => courseName; set => courseName = value; }

        public Course(string courseName)
        {
            this.CourseName = courseName;
            this.StudentArray = new ArrayList();
            this.TeacherArray = new ArrayList();
        }

        // Adds student information to the Student Array
        public void SetStudentInformation(Student student1)
        {
            StudentArray.Add(student1);
            Console.WriteLine("I am within the SetStudentInformation method");
        }

        // Adds teacher information to the Teacher Array
        public void SetTeacherInformation(Teacher teacher1)
        {
            TeacherArray.Add(teacher1);
            Console.WriteLine("I am within the SetTeacheInformation method");
        }

        public void ListStudents()
        {
            foreach(Student student1 in StudentArray)
            {
                Console.WriteLine("{0} {1}", student1.FirstName, student1.LastName);
            }
        }

    }
}
