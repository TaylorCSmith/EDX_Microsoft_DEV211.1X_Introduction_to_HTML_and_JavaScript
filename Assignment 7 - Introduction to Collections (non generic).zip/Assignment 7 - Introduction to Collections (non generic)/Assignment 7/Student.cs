﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_7
{
    class Student : Person
    {
        private static int studentCreationCounter = 0;
        public Stack<int> Grades { get; set; }

        public static int StudentCreationCounter { get => studentCreationCounter; set => studentCreationCounter = value; }

        public Student(string first, string last, int yearsold)
        {
            this.FirstName = first;
            this.LastName = last;
            this.Age = yearsold;
            Grades = new Stack<int>(); 
            StudentCreationCounter++;
        }

        public void TakeTest()
        {
            Console.WriteLine("The student took the test");
        }

        public int GetCounter()
        {
            return StudentCreationCounter;
        }
    }
}
