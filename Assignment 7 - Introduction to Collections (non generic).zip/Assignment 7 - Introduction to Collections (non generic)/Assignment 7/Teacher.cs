﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_7
{
    class Teacher : Person
    {
        public Teacher(string fName, string lName, int yearsold)
        {
            this.Age = yearsold;
            this.LastName = lName;
            this.FirstName = fName;
        }

        public void GradeTest()
        {
            Console.WriteLine("The teacher graded the test");
        }
    }
}
