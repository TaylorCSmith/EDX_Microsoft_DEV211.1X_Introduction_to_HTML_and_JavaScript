﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_7
{
    class Program
    {
        static void Main(string[] args)
        {
            // creating 3 students of the student type
            Student student1 = new Student("Johnny", "Appleseed", 23);
            Student student2 = new Student("Billy", "Bob", 12);
            Student student3 = new Student("Santa", "Clause", 234234);

            // inserting grades into the Grades stack within the student class for each instance of student
            student1.Grades.Push(58);
            student1.Grades.Push(82);
            student1.Grades.Push(92);
            student1.Grades.Push(23);
            student1.Grades.Push(42);

            student2.Grades.Push(23);
            student2.Grades.Push(34);
            student2.Grades.Push(100);
            student2.Grades.Push(98);
            student2.Grades.Push(93);

            student3.Grades.Push(92);
            student3.Grades.Push(99);
            student3.Grades.Push(100);
            student3.Grades.Push(100);
            student3.Grades.Push(100);

            // creating a new course
            Course course1 = new Course("Introduction to Underwater Basketweaving");

            // enters the three student's information into the student ArrayList
            course1.SetStudentInformation(student1);
            course1.SetStudentInformation(student2);
            course1.SetStudentInformation(student3);

            Teacher teacher1 = new Teacher("Master", "Shefu", 23423);

            // inserts the teacher's information into the teacher ArrayList
            course1.SetTeacherInformation(teacher1);

            // Uses the ListStudents method to go through the the student ArrayList and display the first and last name of each student using a forEach loop
            course1.ListStudents();

            // .GetCounter displays the number of students currently within a course. Adds one to a studentcreationcounter everytime a student object is created
            Console.WriteLine(student1.GetCounter());
        }  
    }
}
