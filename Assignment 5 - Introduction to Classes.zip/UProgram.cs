﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment5
{
    public class UProgram
    {
        // name program
        public string Name { get; set; }
        public Degree Degree1 { get; set; }
        public UProgram(string name, Degree degree1)
        {
            this.Name = name;
            this.Degree1 = degree1;
        }

        public string GetName()
        {
            return Name;
        }

    }
}
