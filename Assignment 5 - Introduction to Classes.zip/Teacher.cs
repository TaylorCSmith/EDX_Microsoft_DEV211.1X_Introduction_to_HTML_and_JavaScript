﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment5
{
    public class Teacher
    {
        // Constructors
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string AddressLine1 { get; set; }
        public string AddressLine2 { get; set; }
        public string City { get; set; }
        public string StateProvince { get; set; }
        public string Country { get; set; }
        public DateTime BirthDate { get; set; }
        public int ZipPostalCode { get; set; }

        public Teacher(string FirstName, string LastName, string AddressLine1, string AddressLine2, string City, string StateProvince, string Country, DateTime BirthDate, int ZipPostalCode)
        {
            this.FirstName = FirstName;
            this.LastName = LastName;
            this.AddressLine1 = AddressLine1;
            this.AddressLine2 = AddressLine2;
            this.City = City;
            this.StateProvince = StateProvince;
            this.Country = Country;
            this.BirthDate = BirthDate;
            this.ZipPostalCode = ZipPostalCode;
        }
    }
}
