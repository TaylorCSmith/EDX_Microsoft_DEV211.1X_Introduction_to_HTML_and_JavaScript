﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment5
{
    class Program
    {
        static void Main(string[] args)
        {

            Student student1 = new Student("Johnny", "appleseed", "a1", "a2", "city", "state", "country", new DateTime(02 / 12 / 1232), 23432);
            Student student2 = new Student("Johnny", "appleseed", "a1", "a2", "city", "state", "country", new DateTime(02 / 12 / 1232), 23432);
            Student student3 = new Student("Johnny", "appleseed", "a1", "a2", "city", "state", "country", new DateTime(02 / 12 / 1232), 23432);

            Course course1 = new Course("Programmin with C#");
            course1.SetStudentInformation(student1);
            course1.SetStudentInformation(student2);
            course1.SetStudentInformation(student3);

            Teacher teacher1 = new Teacher("Johnny", "appleseed", "a1", "a2", "city", "state", "country", new DateTime(02 / 12 / 1232), 23432);

            course1.SetTeacherInformation(teacher1);

            Degree degree1 = new Degree("Bachelor of Science", course1);

            UProgram program1 = new UProgram("Information Technology", degree1);

            Console.WriteLine("The {0} program contains the {1} degree", program1.Name, program1.Degree1.Name);
            Console.WriteLine(" ");
            Console.WriteLine("The {0} degree contains the course {1}", program1.Degree1.Name, program1.Degree1.Course1.CourseName);
            Console.WriteLine(" ");
            Console.WriteLine("The {0} course contains {1} students", program1.Degree1.Course1.CourseName, program1.Degree1.Course1.StudentArray[0].getCounter());

        }
    }
}
