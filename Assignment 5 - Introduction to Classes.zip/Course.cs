﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment5
{
    public class Course
    {
        public string CourseName { get; set; }
        public Teacher[] TeacherArray { get; set; }
        public Student[] StudentArray { get; set; }
        public Course(string courseName)
        {
            this.CourseName = courseName;
            this.TeacherArray = new Teacher[3];
            this.StudentArray = new Student[3];
        }

        public void SetStudentInformation(Student student1)
        {
            int counter = 0;
            while (StudentArray[counter] != null)
            {
                counter++;
            }
            StudentArray[counter] = student1;
        }

        public void SetTeacherInformation(Teacher teacher1)
        {
            int counter = 0;
            while (TeacherArray[counter] != null)
            {
                counter++;
            }
            TeacherArray[counter] = teacher1;
        }
    }
}
