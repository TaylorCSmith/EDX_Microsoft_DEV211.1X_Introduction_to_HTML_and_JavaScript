﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment5
{
    public class Degree
    {
        // name degree
        public string Name { get; set; }
        public Course Course1 { get; set; }
        public Degree(string name, Course course1)
        {
            this.Name = name;
            this.Course1 = course1;
        }

        

    }
}
