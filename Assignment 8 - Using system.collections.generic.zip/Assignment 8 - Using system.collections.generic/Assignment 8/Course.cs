﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_8
{
    class Course
    {
        private string courseName;
        private List<Student> studentList;
        private List<Teacher> teacherList;

        public string CourseName { get => courseName; set => courseName = value; }
        public List<Student> StudentList { get => studentList; set => studentList = value; }
        public List<Teacher> TeacherList { get => teacherList; set => teacherList = value; }

        public Course(string courseName)
        {
            this.CourseName = courseName;
            StudentList = new List<Student>();
            TeacherList = new List<Teacher>();
        }

        // insert student information into the StudentList generic list
        public void SetStudentInformation(Student student1)
        {
            StudentList.Add(student1);
        }

        // insert teacher information into the TeacherList generic list
        public void SetTeacherInformation(Teacher teacher1)
        {
            TeacherList.Add(teacher1);
        }

        // method to display all of the students in the StudentList Array
        public void List()
        {
            foreach (Student student in StudentList)
            {
                Console.WriteLine("{0} {1}", student.FirstName, student.LastName);
            }
        }
    }
}
