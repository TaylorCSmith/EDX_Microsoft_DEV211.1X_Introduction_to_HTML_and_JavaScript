﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_8
{
    class Program
    {
        static void Main(string[] args)
        {
            // creates 3 objects of the student type
            Student student1 = new Student("Bruce", "Wayne", 234);
            Student student2 = new Student("Donald", "Drumpf", 2343324);
            Student student3 = new Student("Bernie", "Sanders", 934323423);

            // SetGrades method inserts an integer value into a stack
            student1.SetGrades(24);
            student1.SetGrades(91);
            student1.SetGrades(83);
            student1.SetGrades(82);
            student1.SetGrades(99);

            student2.SetGrades(643);
            student2.SetGrades(2342);
            student2.SetGrades(565);
            student2.SetGrades(0);
            student2.SetGrades(34534);

            student3.SetGrades(4);
            student3.SetGrades(1);
            student3.SetGrades(3);
            student3.SetGrades(2);
            student3.SetGrades(9);

            // displays the grades achieved by the students
            student1.GetGrades();
            student2.GetGrades();
            student3.GetGrades();

            // creating a new object of the course type
            Course course1 = new Course("Underwater Basketweaving");

            // the SetStudentInformation method inserts the information from the above students into the List<Student> StudentList
            course1.SetStudentInformation(student1);
            course1.SetStudentInformation(student2);
            course1.SetStudentInformation(student3);

            // List() displays the first and last name of all students within the List<Student> StudentList
            course1.List();
        }
    }
}
