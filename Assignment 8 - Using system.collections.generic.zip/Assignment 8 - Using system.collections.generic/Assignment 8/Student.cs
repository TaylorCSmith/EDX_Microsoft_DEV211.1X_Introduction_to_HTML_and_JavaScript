﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_8
{
    class Student : Person
    {
        private static int studentCreationCounter;
        private Stack<int> grades;

        public static int StudentCreationCounter { get => studentCreationCounter; set => studentCreationCounter = value; }
        public Stack<int> Grades { get => grades; set => grades = value; }

        public Student(string firstName, string lastName, int age)
        {
            this.FirstName = firstName;
            this.LastName = lastName;
            this.Age = age;
            Grades = new Stack<int>();

            StudentCreationCounter++;
        }

        // keeps count of the number of student type objects created
        public int GetCounter()
        {
            return StudentCreationCounter;
        }

        // inserts a grade into the Grades stack
        public void SetGrades(int grade)
        {
            grades.Push(grade);
        }

        // view all "grades" in the Grades stack
        public void GetGrades()
        {
            Console.Write("{0} {1} got the grades: ", FirstName, LastName);

            foreach(int grade in Grades)
            {
                Console.Write("{0} ", grade);
            }

            Console.WriteLine();
        }

    }
}
